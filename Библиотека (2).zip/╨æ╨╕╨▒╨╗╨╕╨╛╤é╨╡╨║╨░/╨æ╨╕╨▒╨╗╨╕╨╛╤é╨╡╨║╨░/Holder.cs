﻿using System.ComponentModel;

namespace Библиотека
{
    public class Holder
    {
        public static  BindingList<Book> data = new BindingList<Book>();

        public static Library library;
    }
}
